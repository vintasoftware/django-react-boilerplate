from django.shortcuts import render  # noqa


# Create your views here.
