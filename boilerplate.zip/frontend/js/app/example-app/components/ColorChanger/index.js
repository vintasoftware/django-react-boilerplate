import ColorChanger from './ColorChanger';

export default ColorChanger;
