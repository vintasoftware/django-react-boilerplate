import ColorDisplay from './ColorDisplay';

export default ColorDisplay;
