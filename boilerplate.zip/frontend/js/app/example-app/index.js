import ColorChanger from './components';

export default ColorChanger;
