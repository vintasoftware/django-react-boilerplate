import Urls from './urls';

export { Urls }; // eslint-disable-line import/prefer-default-export
