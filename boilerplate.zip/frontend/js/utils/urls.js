const { Urls } = window;

export default Urls;
